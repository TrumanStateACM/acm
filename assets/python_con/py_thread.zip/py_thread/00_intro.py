for i in range(10):
    i *= 2
    print(i)
